/*
  libheif unit tests

  MIT License

  Copyright (c) 2019 Dirk Farin <dirk.farin@gmail.com>

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  SOFTWARE.
*/

#include "catch_amalgamated.hpp"
#include "libheif/heif.h"
#include "image/pixelimage.h"
#include "api_structs.h"
#include "test_utils.h"

#include <string.h>


heif_image* createImage_RRGGBB_BE() {
  heif_image* image;
  heif_error err;
  err = heif_image_create(256,256,
                          heif_colorspace_RGB,
                          heif_chroma_interleaved_RRGGBB_BE,
                          &image);
  if (err.code) {
    return nullptr;
  }

  err = heif_image_add_plane(image,
                             heif_channel_interleaved,
                             256,256, 10);
  if (err.code) {
    heif_image_release(image);
    return nullptr;
  }

  return image;
}


heif_error encode_image(heif_image* img) {
  heif_context* ctx = heif_context_alloc();

  heif_encoder* enc = nullptr;
  heif_error err { heif_error_Ok };

  enc = get_encoder_or_skip_test(heif_compression_HEVC);

  heif_image_handle* hdl;
  err = heif_context_encode_image(ctx,
                                  img,
                                  enc,
                                  nullptr,
                                  &hdl);
  if (err.code) {
    heif_encoder_release(enc);
    heif_context_free(ctx);
    return err;
  }

  heif_encoder_release(enc);
  heif_image_handle_release(hdl);
  heif_context_free(ctx);
  return err;
}


#if 0
TEST_CASE( "Create images", "[heif_image]" ) {
  auto img = createImage_RRGGBB_BE();
  REQUIRE( img != nullptr );

  heif_image_release(img);
}



TEST_CASE( "Encode HDR", "[heif_encoder]" ) {
  auto img = createImage_RRGGBB_BE();
  REQUIRE( img != nullptr );

  REQUIRE( encode_image(img).code == heif_error_Ok );

  heif_image_release(img);
}
#endif

static void test_ispe_size(heif_compression_format compression,
                           heif_orientation orientation,
                           int input_width, int input_height,
                           int expected_minimum_ispe_width, int expected_minimum_ispe_height)
{
  heif_image* img;
  heif_image_create(input_width,input_height, heif_colorspace_YCbCr, heif_chroma_420, &img);
  fill_new_plane(img, heif_channel_Y, input_width, input_height);
  fill_new_plane(img, heif_channel_Cb, (input_width+1)/2, (input_height+1)/2);
  fill_new_plane(img, heif_channel_Cr, (input_width+1)/2, (input_height+1)/2);

  heif_context* ctx = heif_context_alloc();
  heif_encoder* enc = get_encoder_or_skip_test(compression);

  heif_encoding_options* options;
  options = heif_encoding_options_alloc();
  options->macOS_compatibility_workaround = false;
  options->macOS_compatibility_workaround_no_nclx_profile = false;
  options->image_orientation = orientation;

  heif_image_handle* handle;
  heif_error err = heif_context_encode_image(ctx, img, enc, options, &handle);
  UNSCOPED_INFO("heif_context_encode_image: " << err.message);
  REQUIRE(err.code == heif_error_Ok);

  int ispe_width = heif_image_handle_get_ispe_width(handle);
  int ispe_height = heif_image_handle_get_ispe_height(handle);

  REQUIRE(ispe_width >= expected_minimum_ispe_width);
  REQUIRE(ispe_height >= expected_minimum_ispe_height);

  heif_image_handle_release(handle);
  heif_encoder_release(enc);
  heif_encoding_options_free(options);
  heif_context_free(ctx);
  heif_image_release(img);
}


TEST_CASE( "HEVC ispe odd size", "[heif_context]" ) {
  if (!heif_have_encoder_for_format(heif_compression_HEVC)) {
    SKIP("HEVC encoder not available, skipping test");
  }

  // HEVC encoders typically encode with even dimensions only
  test_ispe_size(heif_compression_HEVC, heif_orientation_normal, 121,99, 122,100);
  test_ispe_size(heif_compression_HEVC, heif_orientation_rotate_180, 121,99, 122,100);
  test_ispe_size(heif_compression_HEVC, heif_orientation_rotate_90_cw, 121,99, 122,100);
  test_ispe_size(heif_compression_HEVC, heif_orientation_rotate_90_cw, 120,100, 120,100);
}

TEST_CASE( "AVIF ispe odd size", "[heif_context]" ) {
  if (!heif_have_encoder_for_format(heif_compression_AV1)) {
    SKIP("AV1 encoder not available, skipping test");
  }

  // AVIF encoders typically encode with odd dimensions
  test_ispe_size(heif_compression_AV1, heif_orientation_normal, 121,99, 121,99);
  test_ispe_size(heif_compression_AV1, heif_orientation_rotate_180, 121,99, 121,99);
  test_ispe_size(heif_compression_AV1, heif_orientation_rotate_90_cw, 121,99, 121,99);
  test_ispe_size(heif_compression_AV1, heif_orientation_rotate_90_cw, 120,100, 120,100);
}


TEST_CASE("x265 rejects oversized images", "[heif_encoder]") {
  // Regression test for GHSA-2c3g-p585-8rpq. x265 (up to at least v3.5) neither checks the
  // picture size nor its internal allocation results and crashes in a worker thread for
  // pictures of roughly 700 Mpixel or more. The x265 plugin therefore rejects pictures above
  // the HEVC Level 7.2 maximum of 142,606,336 luma samples (16384x8704), which is the same
  // limit newer x265 versions enforce themselves.

  const heif_encoder_descriptor* descriptor = nullptr;
  int n = heif_get_encoder_descriptors(heif_compression_HEVC, "x265", &descriptor, 1);
  if (n == 0) {
    SKIP("x265 encoder not available, skipping test");
  }

  heif_context* ctx = heif_context_alloc();
  heif_encoder* enc = nullptr;
  heif_error err = heif_context_get_encoder(ctx, descriptor, &enc);
  REQUIRE(err.code == heif_error_Ok);

  // One row more than Level 7.2 allows. A single 8-bit luma plane keeps this at about 142 MB.
  const int w = 16384;
  const int h = 8705;
  heif_image* img = nullptr;
  err = heif_image_create(w, h, heif_colorspace_monochrome, heif_chroma_monochrome, &img);
  REQUIRE(err.code == heif_error_Ok);
  err = heif_image_add_plane(img, heif_channel_Y, w, h, 8);
  REQUIRE(err.code == heif_error_Ok);

  heif_image_handle* handle = nullptr;
  err = heif_context_encode_image(ctx, img, enc, nullptr, &handle);
  REQUIRE(err.code == heif_error_Encoding_error);
  REQUIRE(err.subcode == heif_suberror_Encoder_encoding);

  if (handle) {
    heif_image_handle_release(handle);
  }
  heif_image_release(img);
  heif_encoder_release(enc);
  heif_context_free(ctx);
}


TEST_CASE("kvazaar encodes monochrome images", "[heif_encoder]") {
  // Regression test for PR #1915. kvazaar git master keeps the encoder chroma format in
  // kvz_config fields that only the "input-format" parser updates. Setting input_format
  // directly left the encoder at 4:2:0 while the 4:0:0 input picture had no chroma planes,
  // which crashed every monochrome encode, including every alpha auxiliary image.

  const heif_encoder_descriptor* descriptor = nullptr;
  int n = heif_get_encoder_descriptors(heif_compression_HEVC, "kvazaar", &descriptor, 1);
  if (n == 0) {
    SKIP("kvazaar encoder not available, skipping test");
  }

  heif_context* ctx = heif_context_alloc();
  heif_encoder* enc = nullptr;
  heif_error err = heif_context_get_encoder(ctx, descriptor, &enc);
  REQUIRE(err.code == heif_error_Ok);

  const int w = 128;
  const int h = 128;
  heif_image* img = nullptr;
  err = heif_image_create(w, h, heif_colorspace_monochrome, heif_chroma_monochrome, &img);
  REQUIRE(err.code == heif_error_Ok);
  err = heif_image_add_plane(img, heif_channel_Y, w, h, 8);
  REQUIRE(err.code == heif_error_Ok);

  size_t stride;
  uint8_t* plane = heif_image_get_plane2(img, heif_channel_Y, &stride);
  REQUIRE(plane != nullptr);
  for (int y = 0; y < h; y++) {
    for (int x = 0; x < w; x++) {
      plane[y * stride + x] = (uint8_t) (x + y);
    }
  }

  heif_image_handle* handle = nullptr;
  err = heif_context_encode_image(ctx, img, enc, nullptr, &handle);
  REQUIRE(err.code == heif_error_Ok);
  REQUIRE(handle != nullptr);
  REQUIRE(heif_image_handle_get_width(handle) == w);
  REQUIRE(heif_image_handle_get_height(handle) == h);

  heif_image_handle_release(handle);
  heif_image_release(img);
  heif_encoder_release(enc);
  heif_context_free(ctx);
}
